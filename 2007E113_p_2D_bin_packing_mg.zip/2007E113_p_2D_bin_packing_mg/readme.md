# 程序说明

## 程序入口

init_data.py 测试数据生成文件， 执行`python init_data.py`, 生成的测试数据存储到 data.txt 中。  

gui.py 程序入口，执行 `python gui.py` 运行程序。  