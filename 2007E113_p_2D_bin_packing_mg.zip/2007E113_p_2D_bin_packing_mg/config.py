# 窗口标题
winTitle = 'bin packing'
# 窗口宽度
winWidth = 700
# 窗口高度
winHeight = 600

dataFile = 'data.txt'



